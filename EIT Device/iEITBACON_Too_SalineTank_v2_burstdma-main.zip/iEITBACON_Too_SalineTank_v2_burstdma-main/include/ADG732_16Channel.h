#pragma once
//
//    FILE: ADG732.h
//  AUTHOR: Rob Tillaart
//    DATE: 2023-07-24
// VERSION: 0.1.3
// PURPOSE: Arduino library for ADG732 - 32 to 1 channel multiplexer
//     URL: https://github.com/RobTillaart/ADG732


#include "Arduino.h"

#define ADG732_LIB_VERSION         (F("0.1.3"))

#define ADG732_ALLOFF              0x80


class ADG732
{
public:
  ADG732(uint8_t A, uint8_t B, uint8_t C, uint8_t D, uint8_t WR)
  {
    _addr[0] = A;
    _addr[1] = B;
    _addr[2] = C;
    _addr[3] = D;
    
    _WR = WR;
    _init();
  }

  explicit ADG732(uint8_t address[4],uint8_t WR)
  {
    for(int i = 0; i< 4; i++){
        _addr[i] = address[i];
    }
    _WR = WR;
    _init();
  }
  
  uint8_t getChannel()
  {
    return _channel;
  }

  uint8_t channelCount()
  {
    return 16;
  }
  
  void setChannel(uint8_t channel)
  {
    _channel = channel & 0x0F;
    write(_channel);
  }

private:
  void _init()
  {
    for (int i = 0; i < 4; i++)
    {
      pinMode(_addr[i], OUTPUT);
      digitalWrite(_addr[i], LOW);
    }

    pinMode(_WR, OUTPUT);
    digitalWrite(_WR, HIGH);

    _channel = 0;
  }

  void write(uint8_t data)
  {
    digitalWrite(_WR, LOW);
    uint8_t mask = 0x01;
    for (int i = 0; i < 4; i++)
    {
        digitalWrite(_addr[i], (data & mask) ? HIGH : LOW);
        mask <<= 1;
    }
    delayMicroseconds(1);
    digitalWrite(_WR, HIGH);
  }

  uint8_t  _addr[4];
  uint8_t  _WR;
  uint8_t  _channel;
};


//  -- END OF FILE --
