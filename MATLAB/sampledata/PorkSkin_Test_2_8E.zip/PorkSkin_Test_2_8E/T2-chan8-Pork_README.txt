8 Electrode tank test, Ring diameter(Rd) = 80mm; Wound size(Wsize) = 20mm
Burn time 40s 
Burn temperature = 150 degC

Test target positions:

default: no object	
Center (CnC) Tests: Center nonCond 


