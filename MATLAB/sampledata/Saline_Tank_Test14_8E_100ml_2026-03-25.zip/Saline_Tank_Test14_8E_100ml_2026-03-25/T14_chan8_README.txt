8 Electrode tank test, volume = 100ml d=155mm
Wait 45s between measurements

Test target positions:

default: no object	*#
Center (CnC) Tests: Center nonCond *#
Edge (EnC - E71) Tests: Target between E7 AND E1 *#
Edge (EnC - E53) Tests: Target between E5 AND E3 *#

Center (CC) Tests: Center Cond	*
Edge (EC - E71) Tests: Target between E7 AND E1	*#
Edge (EC - E53) Tests: Target between E5 AND E3 *#


2obj (EnC-E71 + EC-E31):conductive Target between E3 AND E1,nonConductive Target between E7 AND E1 *#
4obj(EnC-E71,E53 + EC-E31,E57)conductive Target between E3&E1+E7&E1  ,nonConductive Target between E5&E3 + E5&E7 *#


