8 channel Electrode tank (d = 155mm) test, for 250ml saline
Wait 45s between measurements

Test target positions:

Edge (EnC - E71) Tests: Target between E7 AND E1 *
Edge (EC - E71) Tests: Target between E7 AND E1 *
Edge (EnC - E53) Tests: Target between E5 AND E3 *#
Edge (EC - E53) Tests: Target between E5 AND E3 *#
Center (CnC) Tests: Center nonCond *#
Center (CC) Tests: Center Cond *#
