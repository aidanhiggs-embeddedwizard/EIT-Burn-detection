8 Electrode tank test, Ring diameter(Rd) = 80mm; Wound size(Wsize) = 50mm
Burn time 40s 

Wait 40s to cool down

Test target positions:

default: no object	
Center (CnC) Tests: Center nonCond 


